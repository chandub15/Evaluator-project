package com.stackroute.plasma.controller;

import com.stackroute.plasma.domain.Evaluator;
import com.stackroute.plasma.service.EvalService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
@RequestMapping(value="api/v1")
public class EvalController {


    @GetMapping("con")
    public ResponseEntity<?> getContent() throws IOException {
        return new ResponseEntity<Evaluator>(EvalService.calScore(), HttpStatus.OK);
    }


    @PostMapping("con")
    public ResponseEntity<?> postScore(@RequestBody Evaluator evaluator) throws IOException {
        ResponseEntity responseEntity;
        responseEntity = new ResponseEntity<String>(EvalService.getScore(), HttpStatus.OK);
        return responseEntity;
    }
}
