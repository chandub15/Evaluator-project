package com.stackroute.plasma.service;

import com.stackroute.plasma.domain.Evaluator;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.IOException;

public class EvalService {

    private static Evaluator evaluator;

    private String[] str={"Define","","","",};


    public static Evaluator  calScore() throws IOException {

         Document doc = Jsoup.connect("https://www.geeksforgeeks.org/encapsulation-in-java/").get();
         String title = doc.title();
         Element element=doc.select("h1").first();
         evaluator.setDescription(element);
         System.out.println(title);
         return evaluator;
    }


    public static String getScore() throws IOException {

        Document doc = Jsoup.connect("https://www.geeksforgeeks.org/encapsulation-in-java/").get();
        evaluator.title = doc.title();
        Element element=doc.select("h1").first();
        evaluator.setDescription(element);
        System.out.println(evaluator.title);
        return evaluator.title;
    }
}
